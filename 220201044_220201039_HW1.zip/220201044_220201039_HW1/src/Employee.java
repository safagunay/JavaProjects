
/**
 * 

 * @author SafaGunay-SerayArslan , 220201044-220201039
 * 
 */

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Employee {

	private String name;

	private int age;

	private Type type;

	private int numberOfHoursWorked;

	private int numberOfHoursOvertimeWorked;

	private int amountOfSale;

	private double salary;

	public enum Type {

		STAFF, PART_TIME, INTERN
	}

	public String getName() {

		return name;
	}

	public int getAge() {

		return age;
	}

	public Type getType() {

		return type;
	}

	public int getNumberOfHoursWorked() {

		return numberOfHoursWorked;
	}

	public int getNumberOfHoursOvertimeWorked() {

		return numberOfHoursOvertimeWorked;
	}

	public int getAmountOfSale() {

		return amountOfSale;
	}

	public double getSalary() {

		return salary;
	}

	public boolean setName(String name) {

		name = validateName(name);
		if (name == null)
			return false;
		this.name = name;
		return true;
	}

	// First validates the name, then returns the "Name Surname" format.
	// If not validated returns null.

	public static String validateName(String name) {

		if (name == null)
			return null;

		Pattern pattern;
		Matcher matcher;

		// Making sure no unrelated username character exists.
		String nonEmployeeNamePattern = "[^a-zA-z\\s]";
		pattern = Pattern.compile(nonEmployeeNamePattern);
		matcher = pattern.matcher(name);

		name = name.replaceAll("\\s+", " ");
		name = name.trim();

		// Name length must be less than 40
		if (!matcher.find() && name.length() <= 40 && name.length() > 3) {
			// Convert the string into format "Name Surname"
			char[] chars = name.toLowerCase().toCharArray();
			chars[0] = Character.toUpperCase(chars[0]);
			boolean found = false;
			for (int i = 1; i < chars.length; i++) {
				if (found) {
					chars[i] = Character.toUpperCase(chars[i]);
					found = false;
					continue;
				}
				if (chars[i] == ' ')
					found = true;
			}
			return String.valueOf(chars);
		} else
			return null;
	}

	public boolean setAge(int age) {

		if (age < 15 || age > 100)
			return false;
		this.age = age;

		return true;
	}

	public boolean setType(String s) {

		Type type = null;
		s = s.replaceAll("\\s+", "_");
		s = s.replaceAll("-", "_");
		s = s.trim();
		try {
			type = Type.valueOf(s.toUpperCase());
		} catch (IllegalArgumentException e) {
			return false;
		}
		this.type = type;
		return true;
	}

	public boolean setType(Type type) {

		if (type != null) {
			this.type = type;
			return true;
		}

		return false;
	}

	public boolean setNumberOfHoursWorked(int numberOfHoursWorked) {

		if (numberOfHoursWorked < 0 || numberOfHoursWorked > 180)
			return false;
		this.numberOfHoursWorked = numberOfHoursWorked;
		return true;
	}

	public boolean setNumberOfHoursOvertimeWorked(int numberOfHoursOvertimeWorked) {

		if (numberOfHoursOvertimeWorked < 0 || numberOfHoursOvertimeWorked > 100)
			return false;
		this.numberOfHoursOvertimeWorked = numberOfHoursOvertimeWorked;
		return true;
	}

	public boolean setAmountOfSale(int amountOfSale) {

		if (amountOfSale < 0)
			return false;
		this.amountOfSale = amountOfSale;
		return true;
	}

	public boolean setSalary(double salary) {

		if (salary < 0)
			return false;
		this.salary = salary;
		return true;
	}

	public String toString() {

		return name + ", " + age + ", " + type + ", " + numberOfHoursWorked + ", " + numberOfHoursOvertimeWorked + ", "
				+ amountOfSale + ", " + salary;
	}

}
