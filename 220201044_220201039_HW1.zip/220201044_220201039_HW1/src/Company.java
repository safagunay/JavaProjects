
/**
 * 
 * @author SafaGunay-SerayArslan , 220201044-220201039
 * 
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Company {

	private ArrayList<Employee> employees;

	public Company() {

	}

	public void start() {

		employees = new ArrayList<Employee>();

		addEmployee("employeeInfo.dir");

		displayMenu();

		int selectedOption = 0;

		boolean goOn = true;

		while (goOn) {

			try {
				selectedOption = Integer.parseInt(getInputFromKeyboard());
			} catch (NumberFormatException e) {
			}

			switch (selectedOption) {

			case 1:
				addEmployee();
				break;

			case 2:
				removeEmployee();
				break;

			case 3:
				calculateSalary();
				break;

			case 4:
				saveEmployeeInfo();
				break;

			case 5:
				saveAverageSalary();
				break;

			default:
				System.out.println("Invalid choice; Enter 9 to quit.");
				break;

			case 9:
				goOn = false;
			}

			if (goOn)
				displayMenu();
		}
	}

	private static String getInputFromKeyboard() {

		Scanner keyboard = new Scanner(System.in);
		String input = keyboard.nextLine();

		return input;
	}

	private void addEmployee(String fileName) {

		try {

			BufferedReader inputStream = new BufferedReader(new FileReader(fileName));

			String line = inputStream.readLine();

			Employee newEmployee;

			while (line != null) {

				newEmployee = createEmployee(line);
				if (newEmployee != null)
					employees.add(newEmployee);
				line = inputStream.readLine();
			}

			inputStream.close();
		}

		catch (FileNotFoundException e) {

			System.out.println("Error: File " + fileName + " not found.");
		}

		catch (IOException e) {

			System.out.println("Error reading from file " + fileName);
		}
	}

	// This function is only used for file input.

	private Employee createEmployee(String line) {

		Employee newEmployee = new Employee();

		StringTokenizer tokens = new StringTokenizer(line, ",\n");

		if (tokens.countTokens() != 7)
			throw new IllegalArgumentException(
					"Error: Invalid input from file!; there should be 7 fields at each line.");

		// Verification performed in Employee class setters.

		String name = tokens.nextToken();

		if (!newEmployee.setName(name))
			throw new IllegalArgumentException("Error: Invalid input from file!; invalid employee name for " + line);

		for (Employee employee : employees) {
			if (employee.getName().equals(newEmployee.getName()))
				throw new IllegalArgumentException(
						"Error: Invalid input from file!;" + employee + " already exists in the company");
		}

		try {
			Integer age = Integer.parseInt(tokens.nextToken().replaceAll("\\s+", ""));
			String type = tokens.nextToken().replaceAll("\\s+", "");
			Integer numberOfHoursWorked = Integer.parseInt(tokens.nextToken().replaceAll("\\s+", ""));
			Integer numberOfHoursOvertimeWorked = Integer.parseInt(tokens.nextToken().replaceAll("\\s+", ""));
			Integer amountOfSale = Integer.parseInt(tokens.nextToken().replaceAll("\\s+", ""));
			Double salary = Double.parseDouble(tokens.nextToken().replaceAll("\\s+", ""));

			if (!newEmployee.setAge(age))
				throw new IllegalArgumentException(
						"Error: Invalid input from file!; invalid employee age for " + newEmployee.getName());

			if (!newEmployee.setType(type))
				throw new IllegalArgumentException(
						"Error: Invalid input from file!; invalid employee type for " + newEmployee.getName());

			if (!newEmployee.setNumberOfHoursWorked(numberOfHoursWorked))
				throw new IllegalArgumentException(
						"Error: Invalid input from file!; invalid number of hours worked for " + newEmployee.getName());

			if (!newEmployee.setNumberOfHoursOvertimeWorked(numberOfHoursOvertimeWorked))
				throw new IllegalArgumentException(
						"Error: Invalid input from file!; invalid number of hours overtime for "
								+ newEmployee.getName());

			if (!newEmployee.setAmountOfSale(amountOfSale))
				throw new IllegalArgumentException(
						"Error: Invalid input from file!; sale can not be nagative for " + newEmployee.getName());

			if (!newEmployee.setSalary(salary))
				throw new IllegalArgumentException(
						"Error: Invalid input from file!; salary can not be negative for " + newEmployee.getName());
		} catch (NumberFormatException e) {
			System.out.println(
					"Error: Invalid input from file!; string entered instead of number for " + newEmployee.getName());
			return null;
		} catch (IllegalArgumentException e) {
			return null;
		}
		return newEmployee;
	}

	private static void displayMenu() {

		System.out.println(
				"\n------------Menu------------\n\n1.Add employee\n2.Remove employee\n3.Calculate salary\n4.Save employee information\n5.Save average of the salaries\n  \n---------------------------");
	}

	private void addEmployee() {

		Employee newEmployee = new Employee();

		System.out.println("Enter employee name :");

		String name = getInputFromKeyboard();

		while (!newEmployee.setName(name)) {
			System.out.println("\nError: invalid employee name entered! Please re-enter\nEnter employee name :");
			name = getInputFromKeyboard();
		}

		// Check whether there is another employee with the same name.

		for (Employee employee : employees) {
			if (employee.getName().equalsIgnoreCase(newEmployee.getName())) {
				System.out.println("\nError:" + name + " already exists!");
				return;
			}
		}

		System.out.println("\nEnter employee age :");

		boolean isTaken = false;
		while (!isTaken) {
			try {
				int age = Integer.parseInt(getInputFromKeyboard());
				while (!newEmployee.setAge(age)) {
					System.out.println("\nError: Invalid employee age entered! Please re-enter\nEnter employee age :");
					age = Integer.parseInt(getInputFromKeyboard());
				}
				isTaken = true;
			} catch (NumberFormatException e) {
				System.out.println("\nError: Invalid employee age entered! Plese re-enter\nEnter employee age :");
			}
		}

		System.out.println("\nEnter employee type : (STAFF, INTERN, PART_TIME)");

		String type = getInputFromKeyboard();
		while (!newEmployee.setType(type)) {
			System.out.println("\nError: Invalid employee type entered! Please re-enter\nEnter employee type :");
			type = getInputFromKeyboard();
		}

		employees.add(newEmployee);
		System.out.println("\nNew employee " + newEmployee.getName() + " has been added successfuly.");
		return;
	}

	private void removeEmployee() {

		System.out.println("Enter employee name :");

		String name = getInputFromKeyboard();
		name = Employee.validateName(name);
		while (name == null) {
			System.out.println("\nError: Invalid employee name entered! Please re-enter\nEnter employee name :");
			name = getInputFromKeyboard();
			name = Employee.validateName(name);
		}

		boolean found = false;
		for (Employee employee : employees) {
			if (employee.getName().equals(name)) {
				employees.remove(employee);
				System.out.println("\nEmployee " + name.toUpperCase() + " has been removed successfuly.");
				found = true;
				break;
			}
		}

		if (!found)
			System.out.println("\n" + name + " is not an employee of the company.");

		return;
	}

	private void calculateSalary() {

		for (Employee employee : employees) {

			System.out.println("\nFor the employee : " + employee.getName() + " (" + employee.getType() + ")");

			while (true) {

				try {

					if (employee.getNumberOfHoursWorked() == 0) {
						System.out.println("Enter the number of hours that the employee worked :");
						while (!employee.setNumberOfHoursWorked(Integer.parseInt(getInputFromKeyboard())))
							System.out.println("\nError: Invalid number of hours entered!\nPlease re-enter :");
					} else
						System.out.println("Number of hours worked:" + employee.getNumberOfHoursWorked());

					if (employee.getNumberOfHoursOvertimeWorked() == 0) {
						System.out.println("Enter the number of hours that the employee overtime worked :");
						while (!employee.setNumberOfHoursOvertimeWorked(Integer.parseInt(getInputFromKeyboard())))
							System.out.println("\nError: Invalid number of overtime hours entered!\nPlease re-enter :");
					} else
						System.out.println(
								"Number of hours worked overtime:" + employee.getNumberOfHoursOvertimeWorked());

					if (employee.getAmountOfSale() == 0) {
						System.out.println("Enter the amount of sale that the employee does :");
						while (!employee.setAmountOfSale(Integer.parseInt(getInputFromKeyboard())))
							System.out.println("\nError:invalid amount of sale entered!\nPlease re-enter :");
					} else
						System.out.println("Amount of sale the employee does:" + employee.getAmountOfSale());
					break;

				} catch (NumberFormatException e) {
					System.out.println("\nError: Invalid number entered!\nPlease re-enter :");
				}
			}

			if (!employee.setSalary(calculateSalary(employee.getType(), employee.getNumberOfHoursWorked(),
					employee.getNumberOfHoursOvertimeWorked(), employee.getAmountOfSale())))
				throw new RuntimeException("\nunexpected error!");
			System.out.println("\nSalary of " + employee.getName() + " is $" + employee.getSalary());
		}

		System.out.println("\nAll salaries have been calculated.");
		return;
	}

	private static double calculateSalary(Employee.Type type, int hours, int overtimeHours, int amountOfSale) {

		double hourly_wage;
		double hourly_overtime_worked_wage;
		double promotion;

		switch (type) {
		case STAFF:
			hourly_wage = 35.00;
			hourly_overtime_worked_wage = 17.50;
			if (amountOfSale >= 50)
				promotion = 100.00;
			else
				promotion = 0.00;
			return (hours * hourly_wage + overtimeHours * hourly_overtime_worked_wage + promotion);
		case PART_TIME:
			hourly_wage = 20.00;
			hourly_overtime_worked_wage = 10.00;
			if (amountOfSale >= 70)
				promotion = 100;
			else
				promotion = 0.00;
			return (hours * hourly_wage + overtimeHours * hourly_overtime_worked_wage + promotion);
		case INTERN:
			hourly_wage = 5.00;
			hourly_overtime_worked_wage = 2.50;
			if (amountOfSale >= 30)
				promotion = 10.00;
			else
				promotion = 0.00;
			return (hours * hourly_wage + overtimeHours * hourly_overtime_worked_wage + promotion);
		}
		return -1.0;
	}

	private void saveEmployeeInfo() {

		for (Employee employee : employees) {

			if (employee.getSalary() == 0) {
				System.out.println("Error : salary of " + employee.getName() + " has not been calculated yet.");
				continue;
			}

			String destFileName = employee.getName().replaceAll("\\s+", "") + ".dat";
			boolean done = true;

			try {

				PrintWriter outputStream = new PrintWriter(new FileOutputStream(destFileName));
				outputStream.println(employee);
				outputStream.close();
			} catch (IOException e) {
				System.out.println("Exception : " + e.getMessage());
				done = false;
			}
			if (done)
				System.out.println(
						"Information of " + employee.getName() + "is written to the " + "\'" + destFileName + "\'");
		}
	}

	private void saveAverageSalary() {

		String destFileName = "averageSalary.dat";

		Scanner inputStream;

		double salarySum = 0;

		for (Employee employee : employees) {

			String sourceFileName = employee.getName().replaceAll("\\s+", "") + ".dat";

			try {
				inputStream = new Scanner(new File(sourceFileName));
				salarySum += Double.parseDouble(inputStream.nextLine().split(", ")[6]);
				inputStream.close();
			} catch (IOException e) {
				System.out.println(
						"Exception : " + e.getMessage() + ": The salary hasn't been calculated yet for the employee "
								+ "\"" + employee.getName() + "\"");
				return;
			} catch (NumberFormatException e) {
				System.out.println("Error: Invalid salary for " + employee.getName());
				return;
			}
		}

		double averageSalary = salarySum / employees.size();

		try {

			PrintWriter outputStream = new PrintWriter(new FileOutputStream(destFileName));
			outputStream.println("Average Salary: $" + averageSalary);
			outputStream.close();
		} catch (IOException e) {
			System.out.println("Exception : " + e.getMessage());
			return;
		}

		System.out.println("The average of salaries is written to the \'averageSalary.dat\'");
	}

}
