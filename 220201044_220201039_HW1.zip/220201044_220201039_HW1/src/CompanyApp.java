/**
 * CompanyApp application is an application for the companies to organize
 * adding, removing operations of employees and enables to save the results to
 * the files or calculates the salary of specific employee or the average
 * salary.
 * 
 * @author SafaGunay-SerayArslan , 220201044-220201039
 */

public class CompanyApp {

	public static void main(String... args) {

		Company company = new Company();
		company.start();
	}

}
